/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package condicionalesnotas;
/**
 *
 * @author Usuario
 */
public class EvaluadorNotas {
        // Atributo
    private double nota;

    // Constructor
    public EvaluadorNotas(double nota) {
        this.nota = nota;
    }

    // Método para determinar si el estudiante aprueba o reprueba
    public String determinarAprobacion() {
        if (nota >= 7.0) {
            return "Aprobado";
        } else {
            return "Reprobado";
        }
    }

    // Método para clasificar el desempeño del estudiante
    public String clasificarDesempeno() {
        if (nota >= 9) {
            return "Excelente";
        } else if (nota >= 7) {
            return "Bueno";
        } else if (nota >= 5) {
            return "Regular";
        } else {
            return "Deficiente";
        }
    }
}
