/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package condicionalesnotas;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class CondicionalesNotas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);

        // Solicitar la nota del estudiante
        System.out.print("Ingrese la nota del estudiante: ");
        double nota = scanner.nextDouble();

        // Crear objeto de la clase EvaluadorNotas
        EvaluadorNotas evaluador = new EvaluadorNotas(nota);

        // Obtener y mostrar los resultados
        String aprobacion = evaluador.determinarAprobacion();
        String desempeno = evaluador.clasificarDesempeno();

        System.out.println("\nResultados:");
        System.out.println("Estado: " + aprobacion);
        System.out.println("Desempeño: " + desempeno);

        scanner.close();
    }
    
}
