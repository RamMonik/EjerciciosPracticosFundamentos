/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package manejoarchivos;

import java.util.Scanner;

/**
 *
 * @author Mónica Ramírez
 */
public class ManejoArchivos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scanner = new Scanner(System.in);
        ArchivoIO archivoIO = new ArchivoIO();

        // Menú para seleccionar la operación
        int opcion;
        do {
            System.out.println("\nSeleccione una operación:");
            System.out.println("1. Leer un archivo");
            System.out.println("2. Escribir en un archivo");
            System.out.println("3. Crear un nuevo archivo");
            System.out.println("4. Eliminar un archivo");
            System.out.println("5. Salir");
            System.out.print("Ingrese su opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del archivo a leer: ");
                    String archivoLeer = scanner.nextLine();
                    archivoIO.leerArchivo(archivoLeer);
                    break;
                case 2:
                    System.out.print("Ingrese el nombre del archivo a escribir: ");
                    String archivoEscribir = scanner.nextLine();
                    System.out.print("Ingrese el contenido a escribir: ");
                    String contenido = scanner.nextLine();
                    archivoIO.escribirArchivo(archivoEscribir, contenido);
                    break;
                case 3:
                    System.out.print("Ingrese el nombre del archivo a crear: ");
                    String archivoCrear = scanner.nextLine();
                    archivoIO.crearArchivo(archivoCrear);
                    break;
                case 4:
                    System.out.print("Ingrese el nombre del archivo a eliminar: ");
                    String archivoEliminar = scanner.nextLine();
                    archivoIO.eliminarArchivo(archivoEliminar);
                    break;
                case 5:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        } while (opcion != 4);

        scanner.close();
    }
    
}
