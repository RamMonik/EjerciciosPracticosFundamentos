/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package usobasicoarray;

/**
 *
 * @author Monica Ramirez
 */
public class Calificaciones {
    // Atributos
    private double[] notas;

    // Constructor
    public Calificaciones(double[] notas) {
        this.notas = notas;
    }

    // Método para calcular el promedio
    public double calcularPromedio() {
        double suma = 0;
        for (double nota : notas) {
            suma += nota;
        }
        return suma / notas.length;
    }

    // Método para encontrar la nota más alta
    public double encontrarNotaMasAlta() {
        double max = notas[0];
        for (double nota : notas) {
            if (nota > max) {
                max = nota;
            }
        }
        return max;
    }

    // Método para encontrar la nota más baja
    public double encontrarNotaMasBaja() {
        double min = notas[0];
        for (double nota : notas) {
            if (nota < min) {
                min = nota;
            }
        }
        return min;
    }
}