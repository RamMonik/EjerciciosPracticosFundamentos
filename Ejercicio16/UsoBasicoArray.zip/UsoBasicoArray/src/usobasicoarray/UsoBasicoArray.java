/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package usobasicoarray;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class UsoBasicoArray {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

        // Solicitar el número de estudiantes
        System.out.print("Ingrese el número de estudiantes: ");
        int cantidadEstudiantes = scanner.nextInt();

        // Crear el array para almacenar las notas
        double[] notas = new double[cantidadEstudiantes];

        // Solicitar las notas al usuario
        for (int i = 0; i < cantidadEstudiantes; i++) {
            System.out.print("Ingrese la nota del estudiante " + (i + 1) + ": ");
            notas[i] = scanner.nextDouble();
        }

        // Crear un objeto de la clase Calificaciones
        Calificaciones calificaciones = new Calificaciones(notas);

        // Calcular y mostrar los resultados
        System.out.println("\nResultados:");
        System.out.println("Promedio de las notas: " + calificaciones.calcularPromedio());
        System.out.println("Nota más alta: " + calificaciones.encontrarNotaMasAlta());
        System.out.println("Nota más baja: " + calificaciones.encontrarNotaMasBaja());

        scanner.close();
    }
    
}
